-- Must be the first line
SIEB = {}

SIEB.name = "AlwaysVisableXPBar"
SIEB.version = "2.18"
SIEB.ignoreOnHideEvent = true
SIEB.configVersion = 5
SIEB.championPointsMax = 400000
SIEB.defaults = {
	minimumAlpha = 0.8,
	showPercentageText = true,
	showCurrentMaxText = true,
	showDuringDialog = false,
	showLabelBelow = true,
}

-- Create a one line text label for placing over an attribute or experience bar
function SIEB.NewBarLabel(name, parent, horizontalAlign)

	local label = WINDOW_MANAGER:CreateControl(name, parent, CT_LABEL)
	label:SetDimensions(200, 20)
	label:SetAnchor(CENTER, parent, CENTER, 0, -1)
	label:SetFont("ZoFontGameBold")
	label:SetColor(0.9, 0.9, 0.9, 1)
	label:SetHorizontalAlignment(horizontalAlign)
	label:SetVerticalAlignment(CENTER)
	return label

end

-- Create the controls for the configuration pannel
function SIEB.CreateConfiguration()

	local LAM = LibStub("LibAddonMenu-2.0")

	local panelData = {
		type = "panel",
		name = "Experience Bar",
		displayName = "AlwaysVisableXPBar",
		author = "@LeaperMessiah",
		version = SIEB.version,
		registerForDefaults = true,
	}

	LAM:RegisterAddonPanel(SIEB.name.."Config", panelData)

	local controlData = {
		[1] = {
			type = "slider",
			name = "Transparency",
			tooltip = "Transparency value for the experience bar",
			min = 0, max = 10, step = 1,
			getFunc = function() return SIEB.vars.minimumAlpha * 10 end,
			setFunc = function(newValue) SIEB.vars.minimumAlpha = newValue / 10.0 end,
			default = SIEB.defaults.minimumAlpha * 10,
		},
		[2] = {
			type = "checkbox",
			name = "Show Percentage Text",
			tooltip = "Show current experience progress as a percentage",
			getFunc = function() return SIEB.vars.showPercentageText end,
			setFunc = function(newValue) SIEB.vars.showPercentageText = newValue; SIEB.RefreshLabel() end,
			default = SIEB.defaults.showPercentageText,
		},
		[3] = {
			type = "checkbox",
			name = "Show Cur/Max Text",
			tooltip = "Show current/maximum experience values",
			getFunc = function() return SIEB.vars.showCurrentMaxText end,
			setFunc = function(newValue) SIEB.vars.showCurrentMaxText = newValue; SIEB.RefreshLabel() end,
			default = SIEB.defaults.showCurrentMaxText,
		},
		[4] = {
			type = "checkbox",
			name = "Show Label Text Below Bar",
			tooltip = "Show the text label below the experience bar instead of above it",
			getFunc = function() return SIEB.vars.showLabelBelow end,
			setFunc = function(newValue) SIEB.vars.showLabelBelow = newValue; SIEB.SetLabelPosition(); SIEB.RefreshLabel() end,
			default = SIEB.defaults.showLabelBelow,
		},
		[5] = {
			type = "checkbox",
			name = "Show Bar During Dialog",
			tooltip = "Continue to show the experience bar during dialog screens",
			getFunc = function() return SIEB.vars.showDuringDialog end,
			setFunc = function(newValue) SIEB.vars.showDuringDialog = newValue; SIEB.UpdateInteractiveScene() end,
			default = SIEB.defaults.showDuringDialog,
		},
	}

	LAM:RegisterOptionControls(SIEB.name.."Config", controlData)

end

function SIEB.GetPlayerXP()

		return GetUnitXP("player")

end

function SIEB.GetPlayerXPMax()

		return GetUnitXPMax("player")

end

function SIEB.GetPlayerChampionXPMax()

	return GetChampionXPInRank(GetPlayerChampionPointsEarned())
	
end

function SIEB.SetLabelPosition()
	
	if not SIEB.experienceLabel then
		SIEB.experienceLabel = SIEB.NewBarLabel("SIEB_ExperienceBarLabel", ZO_PlayerProgressBar, TEXT_ALIGN_CENTER)
	end

	if SIEB.vars.showLabelBelow then
		SIEB.experienceLabel:SetHorizontalAlignment(TEXT_ALIGN_CENTER)
		SIEB.experienceLabel:ClearAnchors()
		SIEB.experienceLabel:SetAnchor(CENTER, ZO_PlayerProgressBarBar, CENTER, 0, 20)
	else
		SIEB.experienceLabel:SetHorizontalAlignment(TEXT_ALIGN_RIGHT)
		SIEB.experienceLabel:ClearAnchors()
		SIEB.experienceLabel:SetAnchor(RIGHT, ZO_PlayerProgressBarBar, RIGHT, 0, -22)
	end

  -- show the champion numbers for players
  if SIEB.championLabel then
    SIEB.championLabel:ClearAnchors()
    SIEB.championLabel:SetAnchor(RIGHT, ZO_PlayerProgressBarBar, RIGHT, -10, 25)
  end

end

-- Initializer functions that runs once when the game is loading addons
function SIEB.Initialize(eventCode, addOnName)

	-- Only initialize our own addon
	if SIEB.name ~= addOnName then return end

	-- Load the saved variables
	SIEB.vars = ZO_SavedVars:NewAccountWide("SIEBVars", SIEB.configVersion, nil, SIEB.defaults)

	-- Create config menu
	SIEB.CreateConfiguration()

	-- Create the top label for the experience bar
	SIEB.SetLabelPosition()

	-- Create the bottom label for the experience bar
	SIEB.flashLabel = SIEB.NewBarLabel("SIEB_ExperienceFlashLabel", ZO_PlayerProgressBar, TEXT_ALIGN_LEFT)
	SIEB.flashLabel:SetAnchor(LEFT, ZO_PlayerProgressBarBar, RIGHT, 7, -2)

	-- Setup the animation for our flash label
	
	SIEB.lastXPValue = SIEB.GetPlayerXP()

	ZO_PreHookHandler(ZO_PlayerProgressBar, 'OnUpdate', SIEB.ExperienceBarOnUpdate)

	-- Add the experience bar to the two hud displays so it always shows up
	SCENE_MANAGER:GetScene("hud"):AddFragment(PLAYER_PROGRESS_BAR_FRAGMENT)
	SCENE_MANAGER:GetScene("hudui"):AddFragment(PLAYER_PROGRESS_BAR_FRAGMENT)
	SCENE_MANAGER:GetScene("hud"):AddFragment(PLAYER_PROGRESS_BAR_CURRENT_FRAGMENT)
	SCENE_MANAGER:GetScene("hudui"):AddFragment(PLAYER_PROGRESS_BAR_CURRENT_FRAGMENT)

	SIEB.UpdateInteractiveScene()

	-- Initialize the label
	SIEB.RefreshLabel()
	
	-- Register for future experience updates
	EVENT_MANAGER:RegisterForEvent("SIEB", EVENT_EXPERIENCE_GAIN, SIEB.OnExperienceGain)
	
end

function SIEB.UpdateInteractiveScene()

	if SIEB.vars.showDuringDialog then
		SCENE_MANAGER:GetScene("interact"):AddFragment(PLAYER_PROGRESS_BAR_FRAGMENT)
		SCENE_MANAGER:GetScene("interact"):AddFragment(PLAYER_PROGRESS_BAR_CURRENT_FRAGMENT)
	else
		SCENE_MANAGER:GetScene("interact"):RemoveFragment(PLAYER_PROGRESS_BAR_FRAGMENT)
		SCENE_MANAGER:GetScene("interact"):RemoveFragment(PLAYER_PROGRESS_BAR_CURRENT_FRAGMENT)
	end

end

function SIEB.ExperienceBarOnUpdate()

	-- Use the OnUpdate event to make sure the alpha value is correct. The alpha
	-- value cannot be set during the OnShow event.
	ZO_PlayerProgressBar:SetAlpha(SIEB.vars.minimumAlpha)

end

function SIEB.OnExperienceGain(eventCode, reason, level, prevExp, curExp)

	-- Ignore the incoming values since the player can still gain experience points
	-- after they hit level 50. Instead, use the event as "some exp/vet point change
	-- happened" and update the label with the value the player wants to see.
	SIEB.RefreshLabel()
	
end

-- Callback for the experience update event
function SIEB.OnExperienceUpdate(eventCode, unitTag, currentExp, maxExp, reason)

	if unitTag ~= "player" then return end

	-- Ignore the incoming values since the player can still gain experience points
	-- after they hit level 50. Instead, use the event as "some exp/vet point change happened"
	-- and update the label with the value the player wants to see.

	SIEB.RefreshLabel()
	
end

-- Manual refresh of the label values
function SIEB.RefreshLabel()

    -- Hide the experience numbers for players that are max rank

    if SIEB.championLabel then
        SIEB.championLabel:SetText(SIEB.FormatLabelText(GetPlayerChampionXP(), SIEB.GetPlayerChampionXPMax()))
	end

end

-- Create the label string based on user preferences
function SIEB.FormatLabelText(current, max)

	local percent = 0
	if max > 0 then
		percent = math.floor((current/max) * 100)
	else
		max = "MAX"
	end

	local str = ""
	
	
	-- Append the "current/maximum" text if configured
	if SIEB.vars.showCurrentMaxText then
		str = str .. current .. " / " .. max
	end

	-- Append the percentage text if configured
	if SIEB.vars.showPercentageText then
		if SIEB.vars.showCurrentMaxText then
			str = str .. "  "
		end
		str = str .. percent .. "%"
	end

	return str

end

-- Register for the init handler (needs to be declaired after the SIEB.Initialize function)
EVENT_MANAGER:RegisterForEvent("SIEB", EVENT_ADD_ON_LOADED, SIEB.Initialize)
